﻿namespace DemoWF2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.btnThanhToan = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnA6 = new System.Windows.Forms.Button();
            this.btnA5 = new System.Windows.Forms.Button();
            this.btnA4 = new System.Windows.Forms.Button();
            this.btnA3 = new System.Windows.Forms.Button();
            this.btnA2 = new System.Windows.Forms.Button();
            this.btnA1 = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblTen = new System.Windows.Forms.Label();
            this.lblTenPhim = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(68, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chọn phim";
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Cuộc phưu lưu của ScooBy-Doo",
            "Sherlock-holmes",
            "Spider-man",
            "Aquaman"});
            this.comboBox1.Location = new System.Drawing.Point(192, 77);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(713, 24);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.comboBox1.SelectionChangeCommitted += new System.EventHandler(this.comboBox1_SelectionChangeCommitted);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(260, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mời bạn chọn ghế trong phòng chiếu phim: ";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 580);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Thành tiền";
            // 
            // lblThanhTien
            // 
            this.lblThanhTien.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblThanhTien.AutoSize = true;
            this.lblThanhTien.BackColor = System.Drawing.Color.Yellow;
            this.lblThanhTien.Location = new System.Drawing.Point(153, 580);
            this.lblThanhTien.Name = "lblThanhTien";
            this.lblThanhTien.Size = new System.Drawing.Size(22, 16);
            this.lblThanhTien.TabIndex = 6;
            this.lblThanhTien.Text = "0đ";
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThanhToan.Location = new System.Drawing.Point(894, 580);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(200, 48);
            this.btnThanhToan.TabIndex = 39;
            this.btnThanhToan.Text = "Thanh toán";
            this.btnThanhToan.UseVisualStyleBackColor = true;
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.66666F));
            this.tableLayoutPanel1.Controls.Add(this.button73, 5, 5);
            this.tableLayoutPanel1.Controls.Add(this.button72, 4, 5);
            this.tableLayoutPanel1.Controls.Add(this.button71, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.button70, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.button69, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.button68, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.button67, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.button66, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.button65, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.button64, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.button63, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.button62, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.button61, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.button60, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.button59, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.button58, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.button57, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.button56, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.button55, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.button54, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.button53, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.button52, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.button51, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.button50, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.button49, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.button48, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.button47, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.button46, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.button45, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnB1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnA6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnA5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnA4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnA3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnA2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnA1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(42, 160);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1055, 387);
            this.tableLayoutPanel1.TabIndex = 40;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button73.Location = new System.Drawing.Point(878, 323);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(174, 61);
            this.button73.TabIndex = 74;
            this.button73.Text = "F6";
            this.toolTip1.SetToolTip(this.button73, "45000");
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Click += new System.EventHandler(this.button69_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button72.Location = new System.Drawing.Point(703, 323);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(169, 61);
            this.button72.TabIndex = 73;
            this.button72.Text = "F5";
            this.toolTip1.SetToolTip(this.button72, "45000");
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Click += new System.EventHandler(this.button69_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button71.Location = new System.Drawing.Point(528, 323);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(169, 61);
            this.button71.TabIndex = 72;
            this.button71.Text = "F4";
            this.toolTip1.SetToolTip(this.button71, "45000");
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button70.Location = new System.Drawing.Point(353, 323);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(169, 61);
            this.button70.TabIndex = 71;
            this.button70.Text = "F3";
            this.toolTip1.SetToolTip(this.button70, "45000");
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Click += new System.EventHandler(this.button69_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button69.Location = new System.Drawing.Point(178, 323);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(169, 61);
            this.button69.TabIndex = 70;
            this.button69.Text = "F2";
            this.toolTip1.SetToolTip(this.button69, "45000");
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button68.Location = new System.Drawing.Point(3, 323);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(169, 61);
            this.button68.TabIndex = 69;
            this.button68.Text = "F1";
            this.toolTip1.SetToolTip(this.button68, "45000");
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Click += new System.EventHandler(this.button69_Click);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button67.Location = new System.Drawing.Point(878, 259);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(174, 58);
            this.button67.TabIndex = 68;
            this.button67.Text = "E6";
            this.toolTip1.SetToolTip(this.button67, "50000");
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Click += new System.EventHandler(this.button69_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button66.Location = new System.Drawing.Point(703, 259);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(169, 58);
            this.button66.TabIndex = 67;
            this.button66.Text = "E5";
            this.toolTip1.SetToolTip(this.button66, "50000");
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Click += new System.EventHandler(this.button69_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button65.Location = new System.Drawing.Point(528, 259);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(169, 58);
            this.button65.TabIndex = 66;
            this.button65.Text = "E4";
            this.toolTip1.SetToolTip(this.button65, "50000");
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Click += new System.EventHandler(this.button69_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button64.Location = new System.Drawing.Point(353, 259);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(169, 58);
            this.button64.TabIndex = 65;
            this.button64.Text = "E3";
            this.toolTip1.SetToolTip(this.button64, "50000");
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.button69_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button63.Location = new System.Drawing.Point(178, 259);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(169, 58);
            this.button63.TabIndex = 64;
            this.button63.Text = "E2";
            this.toolTip1.SetToolTip(this.button63, "50000");
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.button69_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button62.Location = new System.Drawing.Point(3, 259);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(169, 58);
            this.button62.TabIndex = 63;
            this.button62.Text = "E1";
            this.toolTip1.SetToolTip(this.button62, "50000");
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.button69_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button61.Location = new System.Drawing.Point(878, 195);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(174, 58);
            this.button61.TabIndex = 62;
            this.button61.Text = "D6";
            this.toolTip1.SetToolTip(this.button61, "40000");
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.button69_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button60.Location = new System.Drawing.Point(703, 195);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(169, 58);
            this.button60.TabIndex = 61;
            this.button60.Text = "D5";
            this.toolTip1.SetToolTip(this.button60, "40000");
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.button69_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button59.Location = new System.Drawing.Point(528, 195);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(169, 58);
            this.button59.TabIndex = 60;
            this.button59.Text = "D4";
            this.toolTip1.SetToolTip(this.button59, "40000");
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.button69_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button58.Location = new System.Drawing.Point(353, 195);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(169, 58);
            this.button58.TabIndex = 59;
            this.button58.Text = "D3";
            this.toolTip1.SetToolTip(this.button58, "40000");
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.button69_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button57.Location = new System.Drawing.Point(178, 195);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(169, 58);
            this.button57.TabIndex = 58;
            this.button57.Text = "D2";
            this.toolTip1.SetToolTip(this.button57, "40000");
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.button69_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button56.Location = new System.Drawing.Point(3, 195);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(169, 58);
            this.button56.TabIndex = 57;
            this.button56.Text = "D1";
            this.toolTip1.SetToolTip(this.button56, "40000");
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.button69_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button55.Location = new System.Drawing.Point(878, 131);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(174, 58);
            this.button55.TabIndex = 56;
            this.button55.Text = "C6";
            this.toolTip1.SetToolTip(this.button55, "35000");
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button69_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button54.Location = new System.Drawing.Point(703, 131);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(169, 58);
            this.button54.TabIndex = 55;
            this.button54.Text = "C5";
            this.toolTip1.SetToolTip(this.button54, "35000");
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.button69_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button53.Location = new System.Drawing.Point(528, 131);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(169, 58);
            this.button53.TabIndex = 54;
            this.button53.Text = "C4";
            this.toolTip1.SetToolTip(this.button53, "35000");
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.button69_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button52.Location = new System.Drawing.Point(353, 131);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(169, 58);
            this.button52.TabIndex = 53;
            this.button52.Text = "C3";
            this.toolTip1.SetToolTip(this.button52, "35000");
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button69_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button51.Location = new System.Drawing.Point(178, 131);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(169, 58);
            this.button51.TabIndex = 52;
            this.button51.Text = "C2";
            this.toolTip1.SetToolTip(this.button51, "35000");
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.button69_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.button50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button50.Location = new System.Drawing.Point(3, 131);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(169, 58);
            this.button50.TabIndex = 51;
            this.button50.Text = "C1";
            this.toolTip1.SetToolTip(this.button50, "35000");
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button69_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Cyan;
            this.button49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button49.Location = new System.Drawing.Point(878, 67);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(174, 58);
            this.button49.TabIndex = 50;
            this.button49.Text = "B6";
            this.toolTip1.SetToolTip(this.button49, "30000");
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.button69_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Cyan;
            this.button48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button48.Location = new System.Drawing.Point(703, 67);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(169, 58);
            this.button48.TabIndex = 49;
            this.button48.Text = "B5";
            this.toolTip1.SetToolTip(this.button48, "30000");
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.button69_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Cyan;
            this.button47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button47.Location = new System.Drawing.Point(528, 67);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(169, 58);
            this.button47.TabIndex = 48;
            this.button47.Text = "B4";
            this.toolTip1.SetToolTip(this.button47, "30000");
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button69_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Cyan;
            this.button46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button46.Location = new System.Drawing.Point(353, 67);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(169, 58);
            this.button46.TabIndex = 47;
            this.button46.Text = "B3";
            this.toolTip1.SetToolTip(this.button46, "30000");
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button69_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Cyan;
            this.button45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button45.Location = new System.Drawing.Point(178, 67);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(169, 58);
            this.button45.TabIndex = 46;
            this.button45.Text = "B2";
            this.toolTip1.SetToolTip(this.button45, "30000");
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnB1
            // 
            this.btnB1.BackColor = System.Drawing.Color.Cyan;
            this.btnB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnB1.Location = new System.Drawing.Point(3, 67);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(169, 58);
            this.btnB1.TabIndex = 45;
            this.btnB1.Text = "B1";
            this.toolTip1.SetToolTip(this.btnB1, "30000");
            this.btnB1.UseVisualStyleBackColor = false;
            this.btnB1.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA6
            // 
            this.btnA6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA6.Location = new System.Drawing.Point(878, 3);
            this.btnA6.Name = "btnA6";
            this.btnA6.Size = new System.Drawing.Size(174, 58);
            this.btnA6.TabIndex = 44;
            this.btnA6.Text = "A6";
            this.toolTip1.SetToolTip(this.btnA6, "Giá vé của hàng này là: 25.000đ ");
            this.btnA6.UseVisualStyleBackColor = false;
            this.btnA6.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA5
            // 
            this.btnA5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA5.Location = new System.Drawing.Point(703, 3);
            this.btnA5.Name = "btnA5";
            this.btnA5.Size = new System.Drawing.Size(169, 58);
            this.btnA5.TabIndex = 43;
            this.btnA5.Text = "A5";
            this.toolTip1.SetToolTip(this.btnA5, "Giá vé của hàng này là: 25.000đ ");
            this.btnA5.UseVisualStyleBackColor = false;
            this.btnA5.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA4
            // 
            this.btnA4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA4.Location = new System.Drawing.Point(528, 3);
            this.btnA4.Name = "btnA4";
            this.btnA4.Size = new System.Drawing.Size(169, 58);
            this.btnA4.TabIndex = 42;
            this.btnA4.Text = "A4";
            this.toolTip1.SetToolTip(this.btnA4, "Giá vé của hàng này là: 25.000đ ");
            this.btnA4.UseVisualStyleBackColor = false;
            this.btnA4.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA3
            // 
            this.btnA3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA3.Location = new System.Drawing.Point(353, 3);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(169, 58);
            this.btnA3.TabIndex = 41;
            this.btnA3.Text = "A3";
            this.toolTip1.SetToolTip(this.btnA3, "Giá vé của hàng này là: 25.000đ ");
            this.btnA3.UseVisualStyleBackColor = false;
            this.btnA3.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA2
            // 
            this.btnA2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA2.Location = new System.Drawing.Point(178, 3);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(169, 58);
            this.btnA2.TabIndex = 40;
            this.btnA2.Text = "A2";
            this.toolTip1.SetToolTip(this.btnA2, "Giá vé của hàng này là: 25.000đ ");
            this.btnA2.UseVisualStyleBackColor = false;
            this.btnA2.Click += new System.EventHandler(this.button69_Click);
            // 
            // btnA1
            // 
            this.btnA1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnA1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnA1.Location = new System.Drawing.Point(3, 3);
            this.btnA1.Name = "btnA1";
            this.btnA1.Size = new System.Drawing.Size(169, 58);
            this.btnA1.TabIndex = 39;
            this.btnA1.Text = "A1";
            this.toolTip1.SetToolTip(this.btnA1, "Giá vé của hàng này là: 25.000đ ");
            this.btnA1.UseVisualStyleBackColor = false;
            this.btnA1.Click += new System.EventHandler(this.button69_Click);
            // 
            // lblTen
            // 
            this.lblTen.AutoSize = true;
            this.lblTen.Location = new System.Drawing.Point(334, 123);
            this.lblTen.Name = "lblTen";
            this.lblTen.Size = new System.Drawing.Size(0, 16);
            this.lblTen.TabIndex = 41;
            // 
            // lblTenPhim
            // 
            this.lblTenPhim.AutoSize = true;
            this.lblTenPhim.Location = new System.Drawing.Point(345, 123);
            this.lblTenPhim.Name = "lblTenPhim";
            this.lblTenPhim.Size = new System.Drawing.Size(0, 16);
            this.lblTenPhim.TabIndex = 42;
            this.lblTenPhim.Click += new System.EventHandler(this.lblTenPhim_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 677);
            this.Controls.Add(this.lblTenPhim);
            this.Controls.Add(this.lblTen);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnThanhToan);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Chương trình bán vé xem phim";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblThanhTien;
        private System.Windows.Forms.Button btnThanhToan;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnA1;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button btnB1;
        private System.Windows.Forms.Button btnA6;
        private System.Windows.Forms.Button btnA5;
        private System.Windows.Forms.Button btnA4;
        private System.Windows.Forms.Button btnA3;
        private System.Windows.Forms.Button btnA2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblTen;
        private System.Windows.Forms.Label lblTenPhim;
    }
}

